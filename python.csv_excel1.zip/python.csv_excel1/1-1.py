import pandas as pd

import openpyxl
import matplotlib.pyplot as plt
from pathlib import Path
from os.path import join
from pathlib import Path

csv_folder = Path(__file__).parent.resolve()
print(csv_folder)

csv_name=input("csvファイルの名前を　”ファイル名.csv”　という形で入力して")
df = pd.read_csv(
    csv_folder/csv_name,
    encoding="UTF-8-SIG"
)

df["店舗番号"]=0
store_map={}
i=1
for shop in df["店舗名"]:
    if shop not in store_map:
        store_map[shop]=i
        i+=1

df["店舗番号"]=df["店舗名"].map(store_map).fillna(0).astype(int)

df["日付"] = pd.to_datetime(df["日付"], errors="coerce")

df["月"] = df["日付"].dt.month.fillna(0).astype(int)

df=df.sort_values("日付",ascending=True)

t=len(df["店舗名"].unique())

dfs={}
for i in range(1,t+1):
    dfs[i]=df[df["店舗番号"]==i]



month_sum={}
def month_cost(DF,month):
    DF["金額"]=pd.to_numeric(DF["金額"],errors="coerce")
    return DF[DF["月"]==month]["金額"].sum()
for i in range(1,t+1):
    month_sum[i]={}
    dfs[i]
    for m in range(1,13):
        month_sum[i][m]=month_cost(dfs[i],m)


def month_commission(DF,month):
    DF["手数料"]=pd.to_numeric(DF["手数料"],errors="coerce")
    return DF[DF["月"]==month]["手数料"].sum()

columns=["合計金額","手数料","月","店舗名","店舗番号"]
rows=[]
for i in range(1,t+1):
    if dfs[i].empty:
        continue
    shop_name=dfs[i]["店舗名"].iloc[0]

    for m in range(1,13):
        rows.append([
            month_sum[i][m],
            month_commission(dfs[i],m),
            m,
            shop_name,
            i

        ])
summary_df=pd.DataFrame(rows,columns=columns)
summary_df.to_csv(csv_folder/"newtype.csv",
    index=False,
    encoding="UTF-8-SIG")

DFs=pd.read_csv(csv_folder/"newtype.csv",
    encoding="UTF-8-SIG")
DFS={}
for i in range(1,t+1):
    DFS[i]=DFs[DFs["店舗番号"]==i]



with pd.ExcelWriter(csv_folder/"new_excel.xlsx") as writer:
    for i in range(1,t+1):
        dfs[i].to_excel(writer,sheet_name=dfs[i]["店舗名"].iloc[0])
        DFS[i].to_excel(writer,sheet_name=DFS[i]["店舗名"].iloc[0]+str(2))

plt.rcParams["font.family"]="sans-serif"
plt.rcParams["font.family"]=["Hiragino Maru Gothic Pro",
                             "Hiragino sans","BIZ UDGothic","MS Gothic"]
DFD = pd.read_csv(csv_folder/"newtype.csv")
DFD["売上"]=DFD["合計金額"]-DFD["手数料"]

max_store=DFD["店舗番号"].max()
groups={}
group_id=1
for start in range(1,max_store,3):
    store_list=list(range(start,start+3))
    groups[group_id]=DFD[DFD["店舗番号"].isin(store_list)]
    group_id+=1


for group_id,group in groups.items():
    #group_idとgroupの順番大事
    for shop in group["店舗名"].unique():
        data=group[group["店舗名"]==shop].sort_values("月")
        plt.plot(data["月"],data["売上"],marker="o",label=shop)
    plt.title(f"グループ{group_id} 月次売上")
    plt.xlabel("月")
    plt.ylabel("売り上げ（”金額”ー”手数料”）")
    plt.xticks(range(1,13))
    plt.legend()
    plt.grid(True)
    plt.show()

